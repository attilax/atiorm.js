package aaaJobusTest;

import static org.junit.Assert.*;

import java.io.IOException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;

import org.junit.Test;

import com.attilax.exception.ExUtil;
import com.attilax.ioc.IocUtilV2;
import com.attilax.lang.Global;
import com.attilax.net.requestImp;
import com.attilax.web.UrlX;
import com.attilax.web.WriterImp;
import com.attilax.web.responseImp;
import com.attilax.wrmi.WrmiServlet;

public class Applit {
	
	public static void main(String[] args) {
		String s="	http://localhost/wrmiServlet?iocx=nonex&&$method=com.attilax.dataService.DataService.exe&$callback=page_load_callback&$mod=userMod&$view_store_path=com/attilax/order&$op=q&$tb=update%20%20`wxb_order`%20set%20stat%3D%27%E5%8F%96%E6%B6%88%27%20where%20user_id%3D%24uid%24%20and%20oid%3D128&$tbtype=sq&$trigger000=com.attilax.dataService.meta_data_pars_from_txt_trigger&$trigtime=after&order_id=$uuid&user_id=$uid&$member_id=$uid&$fldAppFun={}";

		String queryStr=UrlX.getQueryStr(s);
		System.out.println(queryStr);
	}

	@Test
	public void test() throws IOException, ServletException {
	//	fail("Not yet implemented");
		
		System.setProperty("prj","jobus");//指明是运行的哪个项目
		Cookie ck=new Cookie("null_uid_userMod", "82217764");
		requestImp ri=new requestImp();
		ri.addCookie(ck);
		Global.req.set(ri);
		
		//报名 baomin application
		String pram="$method=com.attilax.dataService.DataService.exe&$callback=page_load_callback&$op=merge"+
"&$tb=wxb_order&order_id=$uuid&good_id=83467578&user_id=$uid";
		Map m=UrlX.getHeader_from_QueryStr(pram);
		ri.setParamMap(m);
		WrmiServlet ws=IocUtilV2.getBean(WrmiServlet.class);
		responseImp paramServletResponse = new responseImp();
		ws.service(ri, paramServletResponse);
		ExUtil.checkExFromJson(paramServletResponse);
		System.out.println("--app rzt:"+ paramServletResponse.rzt() );
		
		
	//-------------cancel application	
	String s="	http://localhost/wrmiServlet?iocx=nonex&&$method=com.attilax.dataService.DataService.exe&$callback=page_load_callback&$mod=userMod&$view_store_path=com/attilax/order&$op=q&$tb=update%20%20`wxb_order`%20set%20stat%3D%27%E5%8F%96%E6%B6%88%27%20where%20user_id%3D%24uid%24%20and%20oid%3D128&$tbtype=sq&$trigger000=com.attilax.dataService.meta_data_pars_from_txt_trigger&$trigtime=after&order_id=$uuid&user_id=$uid&$member_id=$uid&$fldAppFun={}";
	//sql=update  `wxb_order` set stat='取消' where user_id=$uid$ and oid=128
	ri.cancelMap();
	ri.setParamByUrl(s);
	paramServletResponse = new responseImp();
	ws.service(ri, paramServletResponse);
	ExUtil.checkExFromJson(paramServletResponse);
	System.out.println("--can applit rzt:"+ paramServletResponse.rzt() );
	System.out.println("--f");
	}

}
