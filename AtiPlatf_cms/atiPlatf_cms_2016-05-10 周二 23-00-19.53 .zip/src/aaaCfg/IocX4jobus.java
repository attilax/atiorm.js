package aaaCfg;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

//import org.hibernate.Session;
//import org.hibernate.SessionFactory;
//import org.hibernate.engine.spi.SessionFactoryImplementor;
//import org.hibernate.jdbc.Work;
//import org.hibernate.service.jdbc.connections.spi.ConnectionProvider;
//import org.springframework.orm.hibernate4.SessionFactoryUtils;

import java.util.Properties;

//import org.hibernate.Session;
//import org.hibernate.SessionFactory;





















import javax.sql.DataSource;

 






import com.attilax.Closure;
 
import com.attilax.db.DBX;
import com.attilax.hre.UrlDslParser;
import com.attilax.hre.UrlDslParserV3;
import com.attilax.io.pathx;
import com.attilax.lang.Closure2;
import com.attilax.lang.Trigger;
import com.attilax.net.HttpRequest;
import com.attilax.net.requestImp;
import com.attilax.net.websitex;
import com.attilax.order.OrderService;
import com.attilax.order.OrderService4jobus;
import com.attilax.persistence.DBCfg;
import com.attilax.persistence.DbutilX;
//import com.attilax.db.Hb4JdbcX;
//import com.attilax.lang.Closure2;
import com.attilax.persistence.Hbx;
import com.attilax.persistence.HbxX;
import com.attilax.persistence.PX;
import com.attilax.sms.Sms1xinxi;
import com.attilax.sms.SmsService;
import com.attilax.spri.SpringUtil;
import com.attilax.user.UserService;
import com.attilax.user.UserSrvImpDistribVer;
import com.attilax.util.HibernateSessionFactory;
import com.attilax.util.PropX;
import com.attilax.web.UrlDslParserIntr;
import com.csmy.my.center.service.UserInfoService;
//import com.focustar.entity.TMbWeixinuser;
//import com.focustar.util.BaseImpl;
//import com.focusx.dao.BranchManagerDao;
//import com.focusx.dao.impl.BranchManagerDaoImpl;
import com.google.inject.Binder;
import com.google.inject.Guice;
import com.google.inject.Injector;
import com.google.inject.Module;
import com.google.inject.Provider;
import com.google.inject.binder.AnnotatedBindingBuilder;
import com.google.inject.name.Names;

/**
 * aaaCfg.IocX4jobus
 * @author Administrator
 *
 */
public class IocX4jobus {
	static Injector ati;
//	public static void main(String[] args) {
//		System.out.println(getCfgVal("hre_web_url"));
//
//	}
	public static 	String dbcfg_file = pathx
			.webAppPath()
			+ "/WEB-INF/classes/jdbc.properties";
	public static String getCfgVal(String string) {
		 String apptype=System.getProperty("apptype");
		 String cfgpath=pathx.webAppPath()+"/"+apptype+".cfg.txt";
		 PropX px=new PropX(cfgpath);
		return px.getProperty(string);
	}

	public static Map<String, Object> map = new HashMap();
	{
//		map.put("copyright-trigger", new Trigger() {
//
//			@Override
//			public Object exec(Object object) {
//				String fildId = (String) object;
//				String url = "http://120.24.61.254/efilm/a/film/";
//				url = url
//						+ "filmMaster/submitOrder?totalPrice=200&filmId=1&houseId=2&ShopId=23&key=keikdunkdfydfhhkdk343rere";
//				System.out.println(url);
//				String[] split = url.split("\\?");
//				String param = split[1];
//				String urlOnly = split[0];
//				String r = HttpRequest.sendPost(urlOnly, param);
//				System.out.println(r);
//				return r;
//			}
//
//		});
//		map.put("check-playCode-trigger", new Trigger() {
//
//			@Override
//			public Object exec(Object object) {
//				String fildId = (String) object;
//				String cfgPath = Ati4vod.getCfg();
//				String url_inner = PropX.getConfig(cfgPath, "auth-url_innet");
//				// String playserver = PropX.getConfig(cfgPath, "playserver");
//				if (url_inner.contains("%app-path%"))
//					url_inner = url_inner.replaceAll("%app-path%",
//							PropX.getConfig(cfgPath, "app-path"));
//				String authcode_inner = websitex.WebpageContent(url_inner);
//				String url_outer = PropX.getConfig(cfgPath, "auth-url_outer");
//				url_outer = url_outer + authcode_inner;
//				String rezult = websitex.WebpageContent(url_outer);
//				if (rezult.trim().equals("t"))
//					return true;
//				else
//					return false;
//			}
//
//		});

		
	}

	public static Map ini() {
		// map.put("getUserinfoFrmWechatHandler", new
		// Closure<TMbWeixinuser,Object>(){
		//
		// @Override
		// public Object execute(TMbWeixinuser arg0)
		// throws Exception {
		// ExtWebsiteX x=new ExtWebsiteX();
		// x.getUserinfoFrmWechatHandler(arg0);
		// return null;
		// }});
		try {
			map.put("sprx", new Closure() {

				@Override
				public Object execute(Object arg0) throws Exception {
					String p = pathx.classPath() + "/";
					SpringUtil.locations = new String[] { p + "applicationContext.xml"  };
					return new SpringUtil();
				}
			}.execute(null));
		} catch (Exception e) {
			 
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		return map;

	}

	public static void main(String[] args) {
//		DBX dx = IocX.getBean(DBX.class);
//		System.out.println(core.toJsonStrO88(dx
//				.execSql("select * from timer_tab limit 5 ")));
		
	//	SpringUtil sprx=(SpringUtil) IocX4jobus.ini().get("sprx");
		
		UrlDslParser sprx=IocX4jobus.getBean(UrlDslParser.class);;
		sprx.exe(new requestImp());
		//sprx.findBySql("selct * frfom xxx");
		System.out.println(sprx);
		System.out.println("");
	}

	/**
	 * @author attilax 老哇的爪子
	 * @since o92 j_48_40
	 * 
	 * @param class1
	 * @return
	 */
	public static <t> t getBean(Class<t> class1) {
		// attilax 老哇的爪子 j_48_40 o92
		if (ati == null) // ini singleon patter..
		{
			ati = Guice.createInjector(new Module() {

				@Override
				public void configure(Binder bd) {
					
					AnnotatedBindingBuilder<DBCfg> bind = bd.bind(DBCfg.class);
					bind.toInstance(
							getDbcfg().execute(null));
 
				 	bd.bind(DBX.class).to(DbutilX.class);
				 	bd.bind(Connection.class).to(ConnectionImp.class);
					bd.bind(UrlDslParser.class).to(UrlDslParserV3.class);
					bd.bind(UserService.class).to(UserSrvImpDistribVer.class);
					bd.bind(SmsService.class).to(Sms1xinxi.class);
					bd.bind(OrderService.class).to(OrderService4jobus.class);
					
					
					
//					bd.bind(DBX.class).toProvider(new Provider<DBX>() {
//
//						@Override
//						public DBX get() {
////							DataSource ds = (DataSource) SpringUtil
////									.getBean("dataSource");
//
//							try {
//								return new DbutilX();
//							} catch ( Exception e) {
//								// TODO Auto-generated catch block
//								e.printStackTrace();
//							}
//							return null;
//						}
//					});
					 //--------------------
					// ServiceLoctor4vod.inidb();
					// attilax 老哇的爪子 j_s_37 o92
					// bd.bind(DBX.class).to(DbxMybatis.class);
					// bd.bind(guiceT.class); ///jeig bind self def zeush okd
					// ,can not jwemen bind..
					// all def inj can def bind self...can auto bind
					// bd.bind(Session.class).toInstance( (Session) new
					// Closure2(){
					//
					// @Override
					// public Object execute(Object arg0) {
					// SessionFactory sessionFactory =
					// HibernateSessionFactory.getSessionFactory();
					// Session ss;
					//
					// return sessionFactory.openSession();
					// }}.execute(null));
					// // bd.bind(Session.class).toProvider(new
					// Provider<Session>(){
					//
					// @Override
					// public Session get() {
					// SessionFactory sessionFactory =
					// HibernateSessionFactory.getSessionFactory();
					// Session ss;
					//
					// return sessionFactory.openSession();
					// }});
					// bd.bind(Connection.class).toProvider(new
					// Provider<Connection>(){
					//
					// @Override
					// public Connection get() {
					// // SessionFactory sessionFactory =
					// HibernateSessionFactory.getSessionFactory();
					// // Connection c=
					// SessionFactoryUtils.getDataSource(sessionFactory
					// ).getConnection();
					// try {
					// return new Hb4JdbcX().getConnection();
					// } catch (SQLException e) {
					// // TODO Auto-generated catch block
					// e.printStackTrace();
					// throw new RuntimeException(e);
					// }
					// }});
					// // bd.bind(ConnectionProvider.class).toInstance(
					// (ConnectionProvider) new Closure2() {
					//
					// @Override
					// public Object execute(Object arg0) {
					// BaseImpl basedao = new BaseImpl();
					// // final Map m = new HashMap();
					// // m.put("conn", null);
					// //
					// // // m.
					// // // 定义一个匿名类，实现了Work接口
					// // Work work = new Work() {
					// // public void execute(
					// // Connection connection)
					// // throws SQLException {
					// // // 通过JDBC API执行用于批量更新的SQL语句
					// // // conn=connection;
					// // m.put("conn", connection);
					// // }
					// // };
					//
					// // 执行work
					// // basedao.getSession().doWork(work);
					// SessionFactory sessionFactory =
					// HibernateSessionFactory.getSessionFactory();
					// Connection c;
					// try {
					// c= new Hb4JdbcX().getConnection();
					//
					// //ConnectionProvider cp =
					// ConnectionProvider.newConnectionProvider
					// (cfg.getProperties());
					// //cp.getConnection();
					//
					// //Session ssn=sessionFactory.openSession();
					// // ConnectionProvider cp =
					// ((SessionFactoryImplementor)ssn.getSessionFactory()).getConnectionProvider();
					// // c = cp.getConnection();
					// //c = SessionFactoryUtils.getDataSource(sessionFactory
					// ).getConnection();
					// } catch (SQLException e) {
					// // TODO Auto-generated catch block
					// e.printStackTrace();
					// throw new RuntimeException(e);
					// }
					// return c;
					// }
					// }.execute(null));
					// bd.bind(GvDownloadTaskSvs.class);
					bd.bindConstant().annotatedWith(Names.named("thql"))
							.to(" from TUserUsers ");
				}
			});
		}

		return ati.getInstance(class1);

	}


	public static Closure2<Object, DBCfg> getDbcfg() {
		Closure2<Object, DBCfg> closure2 = new Closure2<Object, DBCfg>() {

			@Override
			public DBCfg execute(Object arg0) {
				DBCfg cfg = new DBCfg();
				try {
					// propertyReader pro=new Properties();
				
					FileInputStream fis = new FileInputStream(
							new File(dbcfg_file));
					Properties properties = new Properties();
					properties.load(fis);
					// pro.
					String url = properties
							.getProperty("ct.jdbc.url");
					String driver = properties
							.getProperty("ct.jdbc.driverClassName");

					String uname = properties
							.getProperty("ct.jdbc.username");
					String pwd = properties
							.getProperty("ct.jdbc.password");
					//
					// configuration.configure(propertyFile);
					// String url =
					// configuration.getProperty("connection.url");
					// String driver = configuration
					// .getProperty("connection.driver_class");
					//
					// String uname =
					// configuration.getProperty("connection.username");
					// String pwd =
					// configuration.getProperty("connection.password");
					// // String url =
					// "jdbc:mysql://@host/@db?zeroDateTimeBehavior=convertToNull&allowMultiQueries=true&useUnicode=true&characterEncoding=utf8";

					cfg.setUrl(url);
					cfg.setUser(uname);
					cfg.setPassword(pwd);
					cfg.setDriver(driver);
					return cfg;
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					throw new RuntimeException(
							"cant ini dbcfg", e);
				}

			}
		};
		return closure2;
	}


}
