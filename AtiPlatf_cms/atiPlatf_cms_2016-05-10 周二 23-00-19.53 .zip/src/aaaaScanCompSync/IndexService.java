package aaaaScanCompSync;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.attilax.index.IndexStoreService;
import com.attilax.io.filex;
import com.attilax.lang.Closure2;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;


/**
 * 
 * @author Administrator
 *
 */
@Deprecated
public class IndexService {
	public Map indexs=Maps.newLinkedHashMap();
	public Map createIndex(String indexName, final String filedName,
			List<Map> table) {
Map idx = new HashMap();
//List<Map> cate_Li=Lists.newArrayList();
		for (Map row : table) {
		
			Object filedVal=row.get(filedName);
//			if(filedVaalClosure!=null)
//				filedVal=filedVaalClosure.execute(map);
//			List<Map> cate_Li = (List<Map>) idx.get(filedVal);
//			if (cate_Li == null) {
				// cate_Li=n;
				idx.put(filedVal, row);
			//	cate_Li = (List<Map>) idx.get(filedVal);
	//		}
			//cate_Li.add(row);
		}
		indexs.put(indexName,idx);
		return idx;
	}

	public Map getIndex(String indexName) {
		// TODO Auto-generated method stub
		return (Map) indexs.get(indexName);
	}
	
	 

}
