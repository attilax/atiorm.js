/**
 * 
 */
package com.attilax.acc;

/**
 * @author attilax
 *2016年4月25日 下午10:08:41
 */
public class CantFindAcc extends RuntimeException {

	/**
	 * @param string
	 */
	public CantFindAcc(String string) {
super(string);
	}

}
