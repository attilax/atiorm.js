package com.attilax.acc;

public class AccEx extends RuntimeException {

	public AccEx(String string) {
		super(string);
	}

}
