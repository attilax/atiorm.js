/**
 * 
 */
package com.attilax.dataService;

import java.util.List;
import java.util.Map;

import m.global;

import com.attilax.cc.mainx;
import com.attilax.ioc.IocUtilV2;
import com.attilax.json.AtiJson;
import com.attilax.lang.Global;
import com.attilax.net.requestImp;

/**
 * @author attilax 2016年5月7日 下午5:54:14
 */
public class AtiOrm extends DataService {

	public static void main(String[] args) {
		System.setProperty("prj", "jobus");
		requestImp ri = new requestImp();
		
		
		//查询
		ri.setParam("$op", "select");
		ri.setParam("$table", "sid");
		ri.setParam("$where", "id=2");
		
		
		//insert
		ri.setParam("$op", "insert");
		ri.setParam("$table", "sid");
		ri.setParam("");
		Global.req.set(ri);

		AtiOrm ormx = IocUtilV2.getBean(AtiOrm.class);
		List<Map> li = (List<Map>) ormx.exe();
		System.out.println(AtiJson.toJson(li));
		;

	}

}
