package com.attilax.util;

public class CsvUtil {

	public static String[] toCols(String row) {
//		String[] a2=row.split(":");
//		String dir=a2[0];
//		String files=a2[1];
		String[] files_arr=row.split(",");
		return files_arr;
	}

}
