package com.attilax.util;

import java.io.File;

import com.attilax.lang.Base64;

public class ConnReduce4imgBase64 {
	
	public static void main(String[] args) {
		String d="C:\\workspace\\AtiPlatf_cms\\WebRoot\\index\\img";
		File f=new File(d);
		File[] fs=f.listFiles();
		int i=0;
		for (File file : fs) {
			System.out.println("//---"+file);
			i++;
			String js="var q429img"+String.valueOf(i)+"='$data$';".replace("$data$", Base64.encodeImg(file));
			 System.out.println( js); 
		}
	}

}
