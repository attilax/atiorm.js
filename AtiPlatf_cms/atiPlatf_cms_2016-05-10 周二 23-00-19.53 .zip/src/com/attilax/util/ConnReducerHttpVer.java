package com.attilax.util;

import java.io.IOException;
import java.util.List;

import com.attilax.io.filex;
import com.csmy.my.center.util.zto.HttpUtil;
import com.google.common.collect.Lists;
@Deprecated
public class ConnReducerHttpVer {
	private static List<String>  js_li=Lists.newLinkedList();
	private static List<String>  css_li=Lists.newLinkedList();
	public static String base = "C:\\workspace\\AtiPlatf_cms\\WebRoot";
	private static String output;
	private static String output_css;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		base = "C:\\workspace\\AtiPlatf_cms\\WebRoot";
		output=base+"/index/jobus.js";
		output_css=base+"/index/jobus.css";
		
		List<String>  li=filex.read2list_filtEmptyNstartSpace("c:\\jspath.txt");
		for (String line : li) {
			line=line.trim();
			if(line.length()==0) continue;
			if(line.endsWith(".js"))
				js_li.add(line);
			if(line.endsWith(".css"))
				css_li.add(line);
				
		}
 
		reduce();
		System.out.println("--f");

	}

	private static void reduce() {
		String r="";
		 try {
				filex f=new filex(output);
				for (String js : js_li) {
					String t= 	HttpUtil.sendGet(js);
					
				//	r=r+"\r\n"+t;
					f.append_HP("//-------------"+js+"\r\n");
					f.append_HP(t);
					f.append_HP("\r\n");
				}
				f.close();
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			}
		 
		 try {
				filex f=new filex(output_css);
				for (String js : css_li) {
					String t=filex.read(js);
				//	r=r+"\r\n"+t;
					f.append_HP("//-------------"+js+"\r\n");
					f.append_HP(t);
					f.append_HP("\r\n");
				}
				f.close();
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			}
		
	}

	private static void importx(String string) {
		if(string.endsWith(".js"))
		js_li.add(base+"/"+string);
		if(string.endsWith(".css"))
			css_li.add(base+"/"+string);
	}

}
