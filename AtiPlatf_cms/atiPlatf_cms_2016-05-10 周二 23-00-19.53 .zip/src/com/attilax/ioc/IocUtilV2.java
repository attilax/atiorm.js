/** ver: v2 q418
 * @author attilax 老哇的爪子
	@since  o92 j_48_u$
 */
package com.attilax.ioc;
import aaaCfg.IocX4jobus;

 








import com.attilax.dataService.DataService;
import com.attilax.db.DBX;
import com.attilax.db.DbxMybatis;
import com.attilax.hre.UrlDslParser;
import com.attilax.json.AtiJson;
import com.attilax.lang.Global;
import com.attilax.net.URLEncoder;
import com.attilax.net.UrlEncode_del;
import com.attilax.net.requestImp;
//import com.attilax.net.UrlEncode;
import com.attilax.persistence.HbxX;
import com.attilax.persistence.PX;
//import com.focustar.ServiceLoctor4vod;
//import com.focustar.downtask.GvDownloadTaskSvs;
import com.google.inject.Binder;
import com.google.inject.Guice;
import com.google.inject.Injector;
import com.google.inject.Module;
import com.google.inject.name.Names;

 









import java.util.*;
import java.net.*;
import java.io.*;

import m.global;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.reflect.MethodUtils;
//import org.directwebremoting.extend.AbstractCreator;
//import org.directwebremoting.extend.Creator;
/**
 * @author  attilax 老哇的爪子
 *@since  o92 j_48_u$
 */
public class IocUtilV2   {
//	public	static Injector ati;
	
 
	public static void main(String[] args) {
		System.out.println("");
		System.setProperty("prj","jobus");//指明是运行的哪个项目
	 	DataService dataservice1 = IocUtilV2.getBean(DataService.class);
	 
	 	
	 	//设置request实现类到global变量，以便后续程序获取此request对象
	 	String 	 	sql=URLEncoder.encode("select * from  wxb_good_copy limit 2");
	 	requestImp ri=new requestImp().setQueryString("$table="+sql+"&$tabletype=sql");
	 	Global.req.set(ri);
//	 	$tabletype:table(默认) ,其他取值sql,view,folder,list等。
	 	//$op：select(默认),update,delete
	 	//$where 
	 	
	 	List<Map>  li=(List<Map>) dataservice1.exe();
	 	System.out.println(AtiJson.toJson(li));
	 	
 
	}
	/**
	@author attilax 老哇的爪子
		@since  o92 j_48_40   
	
	 * @param class1
	 * @return
	 */
	public  static  <t> t getBean(Class<t> class1) {
		 String clsName="";
		 String apptype=System.getProperty("apptype");
 	 if(StringUtils.isEmpty(apptype))
 		apptype=System.getProperty("prj");
		 if(StringUtils.isEmpty(apptype))
			 System.out.println("--warning::  sys prop apptype is empty..");
		 if(apptype!=null)
		   clsName="aaaCfg.IocX4@app@".replace("@app@", apptype);
		 if(Global.mainCfg.get()!=null)   //for vod temp change prj
			 clsName=Global.mainCfg.get();
		 if(StringUtils.isEmpty(clsName))
			 throw new RuntimeException("cant find detail ioc cfg class,maybe prj var is not set..");
	Object o=	 com.attilax.reflect.MethodUtils.invokeStaticMethod(clsName, "getBean", (Object)class1);
		// attilax 老哇的爪子  j_48_40   o92 
		 
				
		return    (t) o;
		
	}
	//  attilax 老哇的爪子 j_48_u   o92   
	/* (non-Javadoc)
	 * @see org.directwebremoting.extend.Creator#getType()
	 * @author  attilax 老哇的爪子
	 *@since  o93 l_d_c$
	 */
  
	/**
	@author attilax 老哇的爪子
		@since  o02 4_f_56   
	
	 * @param string
	 */
	public static     <t> t getBean(String className) {
		// attilax 老哇的爪子  4_f_56   o02 
		try {
			Class c=Class.forName(className);
			return (t) getBean(c);
		} catch (ClassNotFoundException e) {
			//  attilax 老哇的爪子 4_h_t   o02   
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	//	return null;
		
	}
}

//  attilax 老哇的爪子