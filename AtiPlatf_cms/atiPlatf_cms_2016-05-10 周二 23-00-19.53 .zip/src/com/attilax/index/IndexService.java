package com.attilax.index;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.attilax.index.IndexStoreService;
import com.attilax.io.filex;
import com.attilax.lang.Closure2;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;


/**
 * 
 * @author Administrator
 *
 */
public class IndexService {
	public Map indexs=Maps.newLinkedHashMap();
	public Map createIndex(String indexName, final String filedName,
			List<Map> table) {
Map idx = new HashMap();
 
		for (Map row : table) {
		
			Object filedVal=row.get(filedName);
		
				
 
				idx.put(filedVal, row);
		 
		}
		indexs.put(indexName,idx);
		return idx;
	}

	public Map getIndex(String indexName) {
		// TODO Auto-generated method stub
		return (Map) indexs.get(indexName);
	}
	
	 

}
