/**
 * 
 */
package com.attilax.lang;

/**
 * @author attilax
 *2016年4月21日 下午9:39:05
 */
public class SecuryEx extends RuntimeException {

	/**
	 * @param string
	 */
	public SecuryEx(String string) {
		super(string);
	}

}
