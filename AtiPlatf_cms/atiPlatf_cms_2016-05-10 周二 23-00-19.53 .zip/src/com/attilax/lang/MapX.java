package com.attilax.lang;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.SetUtils;

import com.attilax.Stream.Mapx;
import com.attilax.io.filex;
import com.attilax.json.AtiJson;
import com.attilax.lang.text.strUtil;
import com.google.common.collect.Maps;
import com.google.gson.Gson;

public class MapX {
	
	public MapX(Map r) {
		this.rzt=r;
	}


	public MapX() {
		// TODO Auto-generated constructor stub
	}


	public static void main(String[] args) {
		System.out.println(getKeysStr(new HashMap(){{
			
			
		 this.put("za", "vv");
		 this.put("bc", "vv");
		}})); 
	}
	

	public static Map newMap() {
		// TODO Auto-generated method stub
		return new HashMap();
	}

	public static Map newOrderMap() {
		// TODO Auto-generated method stub
		return new LinkedHashMap();
	}

 

	public static void put_safe(Map m, String k, String[] a, int i) {
	try {
		m.put(k, a[i]);
	} catch (Exception e) {
		// TODO: handle exception
	}
		
	}

	public static int get(Map m, String nam, int i) {
		try {
			Integer it=(Integer) m.get(nam);
			if(it==null)
				return i;
			else
				return  (Integer) m.get(nam);
		} catch (Exception e) {
			return i;
		}
		 
		
	}

	public static String getKeysStr(Map map) {
	Set st=	map.keySet();
	 
		return strUtil.toStrJoinComma(st);
	}


	public static Map from(String t) {
		
		return 	AtiJson.fromJson (t);
	}


	public static Map reduce(Map req, Set<String> cols) {
		 Map r=new HashMap ();
		 for (String col : cols) {
			 if(req.get(col)!=null)
			r.put(col, req.get(col));
		}
		return r;
	}


	/**
	attilax    2016年4月5日  下午5:40:59
	 * @param m
	 * @return
	 */
	public static Map colon(Map m) {
	Map m2=Maps.newLinkedHashMap();
	m2.putAll(m);
		return m2;
	}


	public static Object getStartWith(Map m, String string) {
		 
		Set<String> st=	m.keySet();
		for (String s : st) {
			if(s.startsWith(string))
				return m.get(s);
		}
	 
		 return "";
	}


	public static String getFileName(Map m, Object string) {
		if(m.get(string)==null)
			return "";
		
		return   filex.fileNameEncode(m.get(string).toString().trim()) ;
	}


	public static String getFileName(Object startWith) {
		// TODO Auto-generated method stub
		return null;
	}



	/**
	attilax    2016年4月29日  下午4:57:54
	 * @param cfgMap
	 * @param key
	 * @return
	 */
	public static Object getContain(Map m, String key) {
		Set<String> st=	m.keySet();
		for (String s : st) {
			if(s.contains(key))
				return m.get(s);
		}
	 
		 return "";
	 
	}


	/**
	attilax    2016年4月29日  下午8:49:44
	 * @param cfgMap
	 * @param key
	 * @return
	 */
	public static Object getKeyBeContained(Map m, String key) {
		Set<String> st=	m.keySet();
		for (String s : st) {
			if(key.contains(s))
				return m.get(s);
		}
	 
		 return "";
	//	return null;
	}

public Map rzt;
public Map tmp1Map;
	public   MapX minus(Map req, Set<String> colsDB) {
		tmp1Map=req;
		 Map r=new HashMap ();
		 Set<String> colsFrmDsl=req.keySet();
		 for (String col : colsFrmDsl) {
			 if( !colsDB.contains(col))
				 r.put(col, req.get(col));
		}
		 rzt=r;
		return new MapX(r);
	}


	public MapX removeDollerKey() {
		 Map r=new HashMap ();
		 Set<String> cols=rzt.keySet();
		 for (String col : cols) {
			   if(!col.trim().startsWith("$"))
				 r.put(col, rzt.get(col));
		}
		 rzt=r;
		return this;
	}

}
