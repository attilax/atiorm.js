/**
 * 
 */
package com.attilax.persistence;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapListHandler;

 






















import aaaCfg.IocX;
import aaaCfg.IocX4nodb;

import com.attilax.core;
 
import com.attilax.api.HandlerChain;
 
 
import com.attilax.biz.seo.getConnEx;
import com.attilax.db.DBX;
import com.attilax.io.pathx;
 
import com.attilax.lang.Global;
import com.attilax.sql.SqlService;
import com.attilax.time.timeUtil;
import com.attilax.util.PropX;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.mysql.jdbc.JDBC4Connection;
 
 

/**dbutils
 * @author ASIMO
 *
 */
public class DbService_freeDbName extends SqlService {

	public DbService_freeDbName(DBCfg cfg) {
		this.dbcfg=cfg;
	}


	public DbService_freeDbName() {
	System.out.println("-------db til  no para ini");
	}
	
	public List executeQuery(String sql)
	{
		return findBySql(  sql);
	//	 return null;
	}


	/**
	@author attilax 老哇的爪子
	@since   p1p g_r_w
	 
	 */
	public static void main(String[] args) {
//		 String sql = " SELECT * FROM `mall_shop_info` sp left join  mall_user_info  ui on  sp.user_id=ui.user_id where sp.user_id=8 ";
//		//  sql= " update mall_shop_info set shop_intro='myintro5' where shop_id=8 ";
//		//  sql=sql+" ; update  mall_user_info set  user_mobile='1358891563'    where user_id=8 ";
//sql="SELECT * FROM  mall_user_info   where  user_id=6 ; SELECT * FROM  mall_user_info   where  user_id=8 ";
//		
//  sql="select * from hx_car where name like '%豪车%'";
//		 DbutilX c= IocX.getBean(DbutilX.class);
//	//	 System.out.println(c.update(sql));
//	 	 List li=c.findBySql(sql);
		 
//	 	 ApiX2 hc=new ApiX2();
//		 hc.hbx=c;
//		
		 String sql="select * from gv_material";
			DbService_freeDbName dx= IocX.getBean(DbService_freeDbName.class);
			 List<Map> li=dx.findBySql(sql);
 		  System.out.println(core.toJsonStrO88(li));
		 System.out.println("--f");

	}
	/**
	 * @Named(value = "aa")
	 */
	 
	DBCfg dbcfg;
	String path = pathx.classPath() + "/website.properties";
	public Connection getConnection() throws getConnEx {
		// com.microsoft.sqlserver.jdbc.SQLServerDriver
	
		//System.out.println(PropX.getConfig(path, "jdbc.url"));
		
		try {
			Class.forName(dbcfg.getDriver());
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			throw new RuntimeException(e1);
		}
	
//		try {
//
//			Class.forName(dbcfg.getDriver());
//		} catch (ClassNotFoundException e) {
//			throw new RuntimeException(e);
//		}
	//	Connection conn;
//
//		conn = DriverManager.getConnection(dbcfg.getUrl(), dbcfg.getUser(), dbcfg.getPassword());
//		
//		try {
//
//			Class.forName("com.mysql.jdbc.Driver");
//		} catch (ClassNotFoundException e) {
//			throw new getConnEx("getconnex" + e.getMessage());
//		}
		//
		//  mysql JDBC4Connection
		
		
		String url=dbcfg.getUrl();
		if(Global.dbName.get()==null)
			throw new RuntimeException(" pls set Global.dbName");
		url=url.replace("@db@", Global.dbName.get());
		dbcfg.setUrl(url);
		Connection conn;
		try {
			conn = DriverManager.getConnection(
					dbcfg.getUrl(),
					dbcfg.getUser(),
					dbcfg.getPassword());
			System.out.println("get conn: "+ conn+" at:"+timeUtil.Now_CST());
			
		} catch (SQLException e) {
			throw new getConnEx("getconnex::" + e.getMessage());
		}
		return conn;
	}
	
	public int executeUpdate(String sql) {
		// TODO Auto-generated method stub
		return  execSql_retInt(sql);
	}
	
	public List<Map> execSql(String sql)
	{
		if(sql.trim().toLowerCase().startsWith("update") || sql.trim().toLowerCase().startsWith("insert"))
		{
			int intx = update(sql);
			 List li=new ArrayList ();
			 li.add(intx);
			return li;
		}
		return findBySql(  sql);
		
	}
	
	public int executeUpdate(Connection conn, String string) {
		PreparedStatement prepareStatement;
		ResultSet resultSet;
		try {
			prepareStatement = conn.prepareStatement(string);
		return 	prepareStatement.executeUpdate() ;
			 
		} catch (SQLException e) {
			 
			 throw new RuntimeException(e);
		}
	}

	public Map uniqueResult(String $sql) {
		List li=findBySql($sql);
		return (Map) li.get(0);
	}
	
	public List findBySql(String sql)  {
		Connection conn;
		 try{
			conn = getConnection();

			// 创建一个QueryRunner
			QueryRunner queryRunner = new QueryRunner(true);
			List<Map<String, Object>> list;

			list = queryRunner.query(conn,
					sql,
					new MapListHandler());
		 
			return list;
	 
		 }
		catch (Exception e) {

			e.printStackTrace();
			throw new RuntimeException(e);
		}

	}
	
	public Integer execSql_retInt(String sql)
	{

// new RuntimeException(" no implt" );
return update(  sql);
	}
	
	
	public int update(String sql)  {
		Connection conn = null;
		 try{
			conn = getConnection();

			// 创建一个QueryRunner
			QueryRunner queryRunner = new QueryRunner(true);
			int list;

			list = queryRunner.update(conn, sql);
		 
			return list;
	 
		 }
		catch (Exception e) {

			e.printStackTrace();
			throw new RuntimeException(e);
		}finally
		{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}


}
