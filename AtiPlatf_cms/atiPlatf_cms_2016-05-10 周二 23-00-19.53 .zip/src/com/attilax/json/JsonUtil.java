package com.attilax.json;

/**
 * com.attilax.json.JsonUtil
 * @author Administrator
 *
 */
public class JsonUtil {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public static String json_encode(Object  args) {
		 return AtiJson.toJson(args);

	}
	

}
