package com.attilax.biz.box;

import java.sql.Connection;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;

import com.attilax.db.DbService;
import com.attilax.ioc.IocUtilV2;
import com.attilax.lang.Global;
import com.attilax.lang.ParamX;
import com.attilax.net.requestImp;
import com.attilax.text.strUtil;
import com.attilax.web.ReqX;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.inject.Inject;

import static com.attilax.web.ReqX.*;
import static com.attilax.lang.text.strUtil.*;
import static com.attilax.json.JsonUtil.*;
import static com.attilax.lang.Global.*;
import static com.attilax.db.MysqlUtil.*;

/**com.attilax.biz.box.BoxService.setTime
 * 
 * @author Administrator
 *
 */
@SuppressWarnings("all")
public class BoxService {
	
	
	public static void main(String[] args) throws InstantiationException, IllegalAccessException {
	//	java.lang.reflect.Constructor
		
		Class c =BoxService.class;
		Object factory =c.newInstance();
		System.setProperty("prj","jobus");//指明是运行的哪个项目
		BoxService s=IocUtilV2.getBean(BoxService.class);
		requestImp ri=new requestImp().setQueryString("timex=7200&movie=ati_movie_name&no=1").setIntoGlobal();
		System.out.println(s.setTime());
	}


	@Inject
	DbService dbsrv;
	public String setTime() {
		HttpServletRequest $_GET = Global.req.get();
		Object $result;
		Map $a = Maps.newLinkedHashMap();
		List $flts = Lists.newLinkedList();
		$GLOBALS("varsx_conn", dbsrv.getConnection());
		// $GLOBALS 		// strUtil		// $no,$tim     
		// $sql="INSERT INTO `wxb_good` ( good_id,good_name,customer_id,good_pic) VALUES('@good_id', '@good_name','@customer_id','@good_pic')";
		String $sql = "update timer_tab set timex=$timex$,movie='$movie$',duration=$duration$ where ip='$ip$'";
		if (StringUtils.isNotEmpty($_GET("no")))
			$sql = "update timer_tab set timex=$timex$,movie='$movie$',duration=7200 where no='$no$'";
		$sql = ParamX.sqlFmt($sql, $_GET);
		$sql = str_replace("@ip", getIP(), $sql);
		$sql = str_replace("@duration", $_GET("timex"), $sql);	 
		$result = mysql_query($sql, $GLOBALS("varsx_conn"));
		// dbExceptionCheck($result,$GLOBALS["varsx"]["conn"]);
		$a.put("ip", getIP());
		$a.put("rzt", $result); 
		for (Object $flt : $flts) {		 
			try {
				execFun($flt);
			} catch (Exception $e) {
				// print_r($e);
			}
		}	 
		return json_encode($a);
	}

	private void execFun(Object $flt) {
		// TODO Auto-generated method stub

	}

}
