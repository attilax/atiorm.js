package com.attilax.sql;

public class SqlSecuryCheckor {

	public static String getFieldValue(String string) {
		// TODO Auto-generated method stub
		return string.replace("'", "''");
	}
	
	public static String val(String string) {
		// TODO Auto-generated method stub
		return string.replace("'", "''");
	}

	public static CharSequence val(Object object) {
		// TODO Auto-generated method stub
		return val(object.toString());
	}


}
