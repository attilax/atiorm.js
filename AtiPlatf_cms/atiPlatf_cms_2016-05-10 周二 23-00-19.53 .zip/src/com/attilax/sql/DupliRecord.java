package com.attilax.sql;

public class DupliRecord extends RuntimeException {

	public DupliRecord(String string) {
		super(string);
	}

}
