/**
 * 
 */
package com.attilax.sql;

/**
 * @author attilax
 *2016年4月25日 下午10:05:36
 */
public class uniqueRowEx extends RuntimeException {

	/**
	 * @param string
	 */
	public uniqueRowEx(String string) {
		super(string);
	}

}
