/**
 * 
 */
package com.attilax.sql;

import java.util.List;
import java.util.Map;

import com.google.inject.Inject;

/**
 * @author attilax
 *2016年4月18日 下午6:23:17
 */
public class SqlSecuryAnalyzer {

	
	
	  @Inject
	 SqlService sqlSrv;
	/**
	attilax    2016年4月18日  下午6:23:51
	 * @param sql
	 */
	public void parse(String sql) {
		  
		
	}

	/**
	attilax    2016年4月18日  下午6:25:28
	 * @param sql
	 */
	public void parse4upOrDel(String sql) {
		
		checkIfSelfData(sql);
		if(sql.trim().startsWith("update" ) ||  sql.trim().startsWith("delete" ))
			if(!sql.contains(" where "))
				throw new SqlSecuryException("modfy statment no lmt exprs");
		
		
		
			
		
	}

	/**
	attilax    2016年4月18日  下午6:37:33
	 * @param sql
	 */
	private void checkIfSelfData(String sql) {
		String trim = sql.trim();
		if(trim.startsWith("select"))
		{
			if(!trim.contains(" limit "))
				sql=sql+" limit 5";
			
			List<Map>  li=sqlSrv.executeQuery(sql);
			for (Map map : li) {
				String uid=getUid();
				
			}
		}
		
	}

	/**
	attilax    2016年4月18日  下午6:41:52
	 * @return
	 */
	private String getUid() {
		// TODO Auto-generated method stub
		return null;
	}

}
