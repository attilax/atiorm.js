/**
 * 
 */
package com.attilax.sql;

/**
 * @author attilax
 *2016年4月25日 下午5:41:49
 */
public class ValidValCheckEx extends RuntimeException {

	/**
	 * @param string
	 */
	public ValidValCheckEx(String string) {
		super(string);
	}

}
