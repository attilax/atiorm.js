/**
 * @author attilax 老哇的爪子
	@since  o0c h_j_43$
 */
package com.attilax.web;
//import com.attilax.core;
import com.attilax.lang.Global;

//import static  com.attilax.core.*;




import java.util.*;
import java.net.*;
import java.io.*;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
/**
 * @author  attilax 老哇的爪子
 *@since  o0c h_j_43$
 */
public class ReqX {

	
	// 定义一个函数getIP()
	public static String getIP(){
	String $ip;
	if (StringUtils.isNotEmpty( getenv("HTTP_CLIENT_IP")))
	$ip = getenv("HTTP_CLIENT_IP");
	else if(StringUtils.isNotEmpty( getenv("HTTP_X_FORWARDED_FOR") ))
	$ip = getenv("HTTP_X_FORWARDED_FOR");
	else if(StringUtils.isNotEmpty( getenv("REMOTE_ADDR")))
	$ip = getenv("REMOTE_ADDR");
	else $ip = "Unknow";
	return $ip;
	}
	private static String getenv(String string) {
		HttpServletRequest request=Global.req.get();
		// TODO Auto-generated method stub
		return request.getHeader(string);  
	}
	public static String $_GET( String param)
	{
		HttpServletRequest request =Global.req.get();
		if(request.getParameter(param)!=null)
			return request.getParameter(param);
		return "";
		
	}
	
	/**
	@author attilax 老哇的爪子
	 * @param request 
		@since  o0c h_j_50   
	
	 * @param string
	 * @return
	 */
	public static boolean isNotEmpty(HttpServletRequest request, String param) {
		// attilax 老哇的爪子  h_j_50   o0c 
		if(request.getParameter(param)!=null && request.getParameter(param).length()>0)
		return true;
		return false;
		
	}
	
	
	public static String getParameter(HttpServletRequest request,String param)
	{
		if(request.getParameter(param)!=null)
			return request.getParameter(param);
		return "";
		
	}
	
//	public static <atitype> atitype copyProperties(HttpServletRequest request,
//			atitype obj) {
//		System.out.println("");
//
//		return request2obj(request, obj);
//	}

//	public static <atitype> atitype request2obj(HttpServletRequest request,
//			final atitype obj) {
//		// todox Apache的BeanUtils的使用入门 enhance effice
//		Map parameterMap = request.getParameterMap();
//		System.out.println(JsonX.toJsonStrO88(parameterMap));
//
//		// 下午12:09:41 2014-6-25 老哇的爪子 Attilax
//		final Map parameterMap2 = parameterMap;
//
//		  final Map mp = convert2commonMapNcaseIngor(parameterMap);
//		// TProbeInvite o = new TProbeInvite();
//		try {
//			// attilax 老哇的爪子 下午02:47:29 2014-5-28
//			BeanUtils.copyProperties(obj, mp);
//			// BeanUtils.populate(formBean, formMap);
//		} catch (Exception e) {
//			// TODO: handle exception
//		}
//
//		return obj;
//
//	}
//	
	

	/**
	 * ]o4f notice:the map val obj is a objArr..maybe for checkbox
	 * 
	 * @param parameterMap
	 * @return
	 */
	public static Map convert2commonMapNcaseIngor(Map<String, Object> parameterMap) {
		Map m = new HashMap();

		for (String key : parameterMap.keySet()) {
			Object obj = parameterMap.get(key);
		//	core.log("key:" + key);
		//	core.log("objtype:" + obj.getClass().getName());
			String[] a = (String[]) obj;
			if (a.length > 0) {
				// obj.
				m.put(key, a[0]);
				m.put(key.toLowerCase(), a[0]);
				// m.put(key, obj.toString());
				// m.put(key.toLowerCase(), obj.toString());
				// 设置参数
				// PropertyUtils.setProperty(user2, key,
				// ConvertUtils.convert(parameterMap.get(key), type));
			}
		}
		return m;
	}
	
	
	public static Map toMap(ServletRequest req) {
		Map m = new HashMap();
Map<String,String[]> parameterMap=req.getParameterMap();
		for (String key : parameterMap.keySet()) {
			Object obj = parameterMap.get(key);
		//	core.log("key:" + key);
		//	core.log("objtype:" + obj.getClass().getName());
			String[] a = (String[]) obj;
			if (a.length > 0) {
				// obj.
				m.put(key, a[0]);
				m.put(key.toLowerCase(), a[0]);
				// m.put(key, obj.toString());
				// m.put(key.toLowerCase(), obj.toString());
				// 设置参数
				// PropertyUtils.setProperty(user2, key,
				// ConvertUtils.convert(parameterMap.get(key), type));
			}
		}
		return m;
	}



	public static boolean isEmpty(HttpServletRequest request, String param) {
		if (request.getParameter(param) == null)

			return true;
		if (request.getParameter(param).trim().length() == 0)
			return true;
		return false;
	}
	//  attilax 老哇的爪子 h_j_43   o0c   


	public static String getParameter(HttpServletRequest req, String para,
			String defVal) {
	//	com.caucho.server.webapp.WebApp

		if(StringUtils.isEmpty(req.getParameter(para)))
		return defVal;
		else
			return req.getParameter(para);
	}
	public static String getRealpath() {
		HttpServletRequest request=Global.req.get();
		
	//	ServletContext
		return	request.getSession().getServletContext().getRealPath(request.getRequestURI());
	//	 null;
	}
	public static String getRealpathDir() {
		String s= getRealpath();
		return new File(s).getParent();
	}
}

//  attilax 老哇的爪子