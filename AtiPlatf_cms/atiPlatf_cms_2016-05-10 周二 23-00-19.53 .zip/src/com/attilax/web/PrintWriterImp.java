package com.attilax.web;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.Writer;

public class PrintWriterImp extends PrintWriter {

	public PrintWriterImp(File file) throws FileNotFoundException {
		super(file);
		// TODO Auto-generated constructor stub
	}

	public PrintWriterImp(String string) throws FileNotFoundException {
		super(new File(string)) ;     
	}

	public PrintWriterImp() throws FileNotFoundException {
		super(new WriterImp());
	}
	
	public String line;
	public void println(String s)
	{
		this.line=s;
	}
	
	

}
