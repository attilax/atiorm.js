package com.attilax.web;

import java.io.IOException;
import java.io.Writer;

public class WriterImp extends Writer {

	@Override
	public void write(char[] cbuf, int off, int len) throws IOException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void flush() throws IOException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void close() throws IOException {
		// TODO Auto-generated method stub
		
	}
	public String line;
	public void println(String s)
	{
		this.line=s;
	}

}
