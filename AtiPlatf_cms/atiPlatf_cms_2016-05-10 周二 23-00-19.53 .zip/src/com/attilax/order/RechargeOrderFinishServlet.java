package com.attilax.order;

import java.io.IOException;
import java.util.Map;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.lang3.reflect.MethodUtils;
import org.apache.struts2.dispatcher.StrutsRequestWrapper;

import aaaCfg.IocX4nodb;

import com.attilax.core;
import com.attilax.hre.UrlDslParser;
import com.attilax.hre.UrlDslParserV2;
import com.attilax.ioc.IocUtilV2;
import com.attilax.ioc.IocXq214;
import com.attilax.json.AtiJson;
import com.attilax.lang.Global;
import com.attilax.ref.refx;
import com.attilax.up.FileUploadService;
import com.attilax.web.ReqX;
import com.attilax.wrmi.JsnaInvoker;
import com.attilax.wrmi.Wrmi;
import com.google.inject.Inject;

/**
 * /CommonServlet?$method= com.attilax.up.FileUploadService.upload
 * 
 * /CommonServlet?$method= com.attilax.up.FileUploadService.process
 * 
 * @author Administrator
 * 
 *         / /jsnaServlet?$method=com.attilax.jsna.test.add&param1=2&param2=3
 *
 */

@WebServlet(name = "wrmiServlet_name", urlPatterns = "/RechargeOrderFinishServlet")
public class RechargeOrderFinishServlet implements Servlet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

	@Override
	public ServletConfig getServletConfig() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getServletInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void init(ServletConfig paramServletConfig) throws ServletException {
		
		UrlDslParserx = IocXq214.getBean(UrlDslParser.class);
		

	}

	public static ThreadLocal<ServletResponse> resp = new ThreadLocal<ServletResponse>();

	@Inject
	UrlDslParser UrlDslParserx;

	@Override
	public void service(ServletRequest req, ServletResponse paramServletResponse)
			throws IOException, ServletException {
		
		HttpServletRequest req2=(HttpServletRequest) req;
	
		
		RechargeOrderService srv = IocUtilV2
				.getBean(RechargeOrderService.class);
		Map m =ReqX.toMap(req);
		m.put("$table", "orderv2");
		m.put("order_id",m.get("orderid").toString());
		try {
			Integer r=(Integer) srv.finish(m);
			HttpServletResponse	resp=(HttpServletResponse) paramServletResponse;
			if(req2.getMethod().toLowerCase().equals("get"))
				resp.sendRedirect("/acc/recharge_finish.html?retcode="+r.toString());
			else
				paramServletResponse.getWriter().println(r);
		} catch (Exception e) {
			String s=AtiJson.toJson(e);
			paramServletResponse.getWriter().println(s);
		}
		

	}

}
