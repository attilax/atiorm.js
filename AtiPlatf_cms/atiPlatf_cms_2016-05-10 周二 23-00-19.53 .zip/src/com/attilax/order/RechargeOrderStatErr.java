package com.attilax.order;

public class RechargeOrderStatErr extends RuntimeException {

	public RechargeOrderStatErr(String string) {
		super(string);
	}

}
