package com.attilax.order;

public class OrderFinishEx extends RuntimeException {

	public OrderFinishEx(String string) {
		super(string);
	}

}
