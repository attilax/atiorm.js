package com.attilax.order;

public class CantFindRechargeOrder extends RuntimeException {

	public CantFindRechargeOrder(String string) {
		super(string);
	}

//	public CantFindRechargeOrder(String string) {
//		// TODO Auto-generated constructor stub
//	}

}
