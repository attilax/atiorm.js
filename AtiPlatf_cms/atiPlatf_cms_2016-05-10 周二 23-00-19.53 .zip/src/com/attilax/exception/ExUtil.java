package com.attilax.exception;

import java.io.IOException;
import java.util.Map;

import com.attilax.json.AtiJson;
import com.attilax.web.PrintWriterImp;
import com.attilax.web.WriterImp;
import com.attilax.web.responseImp;

public class ExUtil {

	/**
	 * 
	 * @param e3
	 */
	public static void throwEx(Throwable e3) {
		 if( e3 instanceof RuntimeException)
			  throw (RuntimeException)e3;
		  else
			  throw new RuntimeException(e3);
		
	}

	public static void checkExFromJson(responseImp paramServletResponse) {
		PrintWriterImp wi;
		try {
			wi = (PrintWriterImp)paramServletResponse.getWriter();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException(e);
		}
		
		String r=wi.line;
		try {
			@SuppressWarnings("rawtypes")
			Map m=	AtiJson.fromJson(r);
			if(m.get("@type").toString().contains("Exception"))
				throw new RuntimeException(r);
		} catch (Exception e) {  //maybe not json fmt
		     
		}
	
		
	}

}
