/**
 * 
 */
package com.attilax.task;

/**
 * @author attilax
 *2016年4月20日 下午3:56:45
 */
public class FutureTask {
	public static void main(String[] args)   {
		
		String url="$trigger=aaaCfg.DataMapper4vod&$triggerPos=after";
		Map m=UrlX.getHeader_from_QueryStr(url);
		requestImp ri=new requestImp();
		ri.setParam("$mainCfg", "aaaCfg.IocX4sqlite");
		ri.setParam("$op", "select");
		ri.setParam("$table", "hitv");
		ri.setParam("$where" , " genre like '%动作%' limit 10000 ");
	
	//	ri.setParamMap(m);
		Global.req.set(ri);
		
		Global.mainCfg.set("aaaCfg.IocX4sqlite");
		DataService dx = IocX4sqlite.getBean(DataService.class);
		Object rows = dx.exe();
		
		//System.out.println( AtiJson.toJson (rows));
		/*
		 * 	"posterPicString":"死亡飞车/死亡飞车-poster.jpg",
		"fanartPicString":"死亡飞车/死亡飞车-fanart.jpg",
		 * */
		List<Map> li=(List<Map>) rows;
		System.out.println( li.size() );
		//ExecutorService fixedThreadPool = Executors.newFixedThreadPool(50);
		for (Map map : li) {
			
			FutureTask<String> fut=new FutureTask(new Callable<String>() {

				@Override
				public String call() throws Exception {
					copyFile((String) map.get("fanartPicString"));
					copyFile((String) map.get("posterPicString"));
					return null;
				}
			}) ;
			//fixedThreadPool.submit(fut);
			core.submit(fut, "fut");
			core.newThread(new Runnable() {
				
				@Override
				public void run() {
					 
					try {
						System.out.println(fut.get(7, TimeUnit.SECONDS));
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (ExecutionException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (TimeoutException e) {
						  fut.cancel(true);
						e.printStackTrace();
					}
				}
			}, "threadName");
			Runnable runnable = new Runnable() {
				public void run() {
					 
						copyFile((String) map.get("fanartPicString"));
						copyFile((String) map.get("posterPicString"));
					 
				}

			};
		//	fixedThreadPool.execute(runnable);
		}
		
		System.out.println("--f");
		
	}

}
