package com.attilax.db;

public class getConnEx extends RuntimeException {

	public getConnEx(String string) {
		super(string);
	}

}
