package com.attilax.db;

public class MysqlDMLSql {

	
	public static	String addCol=" alter table $tab$ add $col$ varchar(1000) ";
}
