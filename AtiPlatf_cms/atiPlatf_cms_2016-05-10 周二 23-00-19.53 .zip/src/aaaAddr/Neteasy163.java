/**
 * 
 */
package aaaAddr;

import com.attilax.cmsPoster.FirefoxDriver;
import com.attilax.io.pathx;

/**
 * @author attilax
 *2016年4月25日 下午6:07:38
 */
public class Neteasy163 {

	/**
	attilax    2016年4月25日  下午6:07:38
	 * @param args
	 */
	public static void main(String[] args) {
		String url="http://reg.email.163.com/unireg/call.do?cmd=register.entrance&from=163navi&regPage=163";
		String ffpath = pathx.webAppPath()
				+ "\\Mozilla Firefox\\firefox.exe";
		System.setProperty("webdriver.firefox.bin", ffpath);
		FirefoxDriver driver =null;
		driver = new FirefoxDriver();
	}

}
