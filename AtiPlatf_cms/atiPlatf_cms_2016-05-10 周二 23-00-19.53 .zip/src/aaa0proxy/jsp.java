package aaa0proxy;

import org.eclipse.jetty.server.Connector;
import org.eclipse.jetty.server.Server;
 

public class jsp {
	
	public static void main(String[] args) {
		
		org.apache.commons.exec.Executor
		Connector connector = new SelectChannelConnector();
		connector.setPort(8080);
		server.setConnectors(new Connector[] { connector }); 
		WebAppContext webAppContext = new WebAppContext("WebContent","/");
		webAppContext.setDescriptor("WebContent/WEB-INF/web.xml");
		webAppContext.setResourceBase("WebContent");
		webAppContext.setDisplayName("jetty");
		webAppContext.setClassLoader(Thread.currentThread().getContextClassLoader());
		webAppContext.setConfigurationDiscovered(true);
		webAppContext.setParentLoaderPriority(true);
		server.setHandler(webAppContext);
		
		try{
			server.start();
		}catch(Exception e){
		}

	}

}
