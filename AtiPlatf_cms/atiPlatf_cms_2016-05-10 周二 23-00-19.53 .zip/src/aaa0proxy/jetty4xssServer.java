package aaa0proxy;
 
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;

//import jcifs.smb.SmbFile;

import org.eclipse.jetty.server.Handler;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.Request;
import org.eclipse.jetty.server.handler.AbstractHandler;
import org.slf4j.helpers.MessageFormatter;

import com.attilax.io.filex;
import com.attilax.net.urlEncode;
import com.attilax.web.UrlX;
 

/**jetty 9.3.7
 * aaaAddr.jetty4xssServer
 * @author Administrator
 *
 */
public class jetty4xssServer extends AbstractHandler
{
  //  private String smb;

	public void handle(String target,
                       Request baseRequest,
                       HttpServletRequest request,
                       HttpServletResponse response) 
        throws IOException, ServletException
    {
    //   response.setContentType("image/jpeg;charset=utf-8");
//		application/octet-stream  mkv gazi
        response.setStatus(HttpServletResponse.SC_OK);
        baseRequest.setHandled(true);
        
        String smb=request.getParameter("smb");
        if(smb==null) return;
     //   smb=UrlX.encodeURI(smb);
        
        
        String target2 = "c:\\0key\\"+filex.getUUidName()+".txt";
		filex.save(smb, target2);
    	
  
		
		// 获取文件类型
	//	String contentType = FileUtil.getFileType(filePaths);
		// 获取文文件流
//		InputStream contentIn = file.getInputStream();
//		 convertStream(contentIn,response.getOutputStream());
		 
		  
		
  //      response.setContentInputStream(contentIn);
       response.getWriter().println("ok"+target2);
    }
 
    private void convertStream(InputStream in,
			 OutputStream out) {
//    	InputStream  in = new FileInputStream(srcFile);  
//          out = new FileOutputStream(destFile);  
          byte[] buffer = new byte[1024];  

          int byteread;
		try {
			while ((byteread = in.read(buffer)) != -1) {  
			      out.write(buffer, 0, byteread);  
			  }
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException(e);
		}  
		try {
			in.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}try {
			out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

    /**
     * http://127.0.0.1:7777/?smb=smb%3A%2F%2F192.168.2.106%2Fe%2F%E9%9D%9E%E8%93%9D%E5%85%89%2F9%E8%B7%AF%E5%86%A5%E5%A9%9A%2F9%E8%B7%AF%E5%86%A5%E5%A9%9A-fanart.jpg
     * http://127.0.0.1:7777/?smb=smb%3A%2F%2F192.168.2.106%2Fe%2F%E9%9D%9E%E8%93%9D%E5%85%89%2F9%E8%B7%AF%E5%86%A5%E5%A9%9A%2F9%E8%B7%AF%E5%86%A5%E5%A9%9A.mkv


     * @param args
     * @throws Exception
     */
	public static void main(String[] args) throws Exception
    {
		MessageFormatter.arrayFormat(messagePattern, argArray)
		String smb="smb://192.168.2.106/e/非蓝光/9路冥婚/9路冥婚-fanart.jpg";
		smb=URLEncoder.encode(smb, "utf8");
		System.out.println(smb);
        Server server = new Server(7777);
        server.setHandler(new jetty4xssServer());
  
        server.start();
        System.out.println("--staered");
        server.join();
        System.out.println("--f");
    }

//	private jettyFileServer setSmb(String smb) {
//		this.smb=smb;
//		return this;
//	}
}