/**
 * 
 */
package aaaantlr;

import org.antlr.runtime.ANTLRStringStream;
import org.antlr.runtime.CommonTokenStream;

import com.attilax.json.AtiJson;

/**
 * @author attilax
 *2016年4月22日 下午5:02:26
 */
public class grm1Test {

	/**
	attilax    2016年4月22日  下午5:02:26
	 * @param args
	 */
	public static void main(String[] args) {
	 
run("where=\"atiq422\"");
System.out.println("--f");
	}
	
	public static void run(String expr) { 
		 ANTLRStringStream in = new ANTLRStringStream(expr); 
		 grm1 lexer = new grm1(in); 
			 CommonTokenStream tokens = new CommonTokenStream(lexer); 
			 System.out.println(AtiJson.toJson(tokens));
		//	 ExprParser parser = new ExprParser(tokens); 
	//		 parser.prog(); 	
		 }

}
