 
not_show_user_type=true;
def_user_type="mer";
hre_web_url="/wrmiServlet";

$app_path="";   
app_path="";
$approot="";  
  approot="";  
$envi="java";
 
$iocx_iner="nonex";
$iocx="nonex";
hre_web_url="/wrmiServlet";