importx("com.attilax/web/dslUtil.js");
importx("com.attilax/core/jqUtil.js");
importx("com.attilax/core/ex.js");
importx("com.attilax/core/core.js");
importx("com.attilax/text/str.js");
importx("com.attilax/web/urlUtil.js");
importx("com.attilax/templete/jquery.tmpl.js");
importx("com.attilax/jsbridge/jsb_v7q329.js");
importx("00.atilax.frmwk/validation.js");
importx("com.attilax/util/valid.js");
importx("com.attilax/valide/SmsValider.js");

 

 var $isUseCaptcha=true;

function bindValid()
{
     AtiValid.bind_valid_rules("username",   {
        required: true,
        minlength: 2,msg:"手机号不能为空"
       } 

       );

       AtiValid.bind_valid_rules("captcha",   {
        required: true,
        minlength: 2,msg:"验证码不能为空"
       } 

       );

	   

}

 //	alert(a1111); 
 //	java.lang.System.out.println("Your message");

 function btnReg_click()
 {



     var brj=new AtiJsBridge();
  var param=$("form").serialize()+"&"+getQueryStr();
brj.exe("$method=com.attilax.user.UserService.resetPwd&"+param  ,function(data){

						  try{
								  callback_checkJavaEx(data);
							  }catch(e)
							  {
							  	var o=str2json(data);
							  	if(o.message.startWith("chkex"))
							  	{
							  		   logx(o.message);
							  		   var a=o.message.split(",");
							  			alert(a[2]);
							  			return;
							  	}
							  
							  		showErr(e);
							  		return;
							  }

							  if(data==0)
							  	alert("返回结果:0,可能不存在此手机号，请检查")
							  else
							alert("ok");

			} );
 

 }

 function page_load()
 {
 	 
	var sms="您的验证码为：$capt$请勿向任何人泄露。非本人操作请忽略本短信，如有疑问请致电18706173108.【职达巴士】";
 	 var smsValid=new SmsValider("capt_btn");
 	 //inject valid server
 //	 smsValid.validor_BefSendSms=null;
 	smsValid.senderCssSelector="#username";
 	 smsValid.tmpl=sms;
 	 smsValid.ini();



 bindValid();

   $("#btnReg").on("click",  function () {
btnReg_click();            });


 }



 
	


 


