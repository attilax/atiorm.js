// JavaScript Document
function btn_click()
{
	if($("#amount").val()=="")
	{
			alert("金额不能为空");return;
	}
	//alert(window.alert);
	insert_rech_order(function(uuid){
		var url="alipay_ifrm.html?amout="+encodeURIComponent($("#amount").val())+"&uuid="+uuid;
		//alert(url);
		 window.location=url;
		});
	
	
}

importx("com.attilax/jsbridge/jsb_v7q329.js");
importx("com.attilax/dataService/dataServiceV4q423.js");
function insert_rech_order(callback)
{
	var ds3=new dataServiceV4();
	ds3.disableDefRetOkMsg=true;
	var uuid=getUuid();
	ds3.insert("$tb=orderv2&uid=$uid&order_id="+uuid+"&money="+$("#amount").val(),function(ret_data							){
	//	alert("ret:"+ret_data);	
	if(ret_data!=1)
	{
		alert("ret:"+ret_data);	return;
	}
	callback(uuid);
 
	 
		
	});
}
