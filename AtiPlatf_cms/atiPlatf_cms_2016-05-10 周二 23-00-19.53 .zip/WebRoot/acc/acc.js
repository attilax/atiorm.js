// JavaScript Document
importx("com.attilax/web/dslUtil.js");
importx("com.attilax/core/jqUtil.js");
importx("com.attilax/core/ex.js");
importx("com.attilax/core/core.js");
importx("com.attilax/text/str.js");
importx("com.attilax/web/urlUtil.js");
importx("com.attilax/templete/jquery.tmpl.js");



//com.attilax/text/str.js
importx("com.attilax/jsbridge/jsb_v7q329.js");
importx("com.attilax/dataService/dataServiceV3q41.js");
function page_load()
{
	var ds3=new dataServiceV3();
	var whr="user_name='$uid$'";
	whr=encodeURIComponent(whr);
	ds3.query("$tb=ecs_users&$where="+whr,function(ret_data){
		//alert("ret:"+ret_data);	
		var  arr=str2json(ret_data);
		if(arr.length==0)
			$("#FeeLeftLabel").text("0.00");
		else
			$("#FeeLeftLabel").text(arr[0].user_money);
	});
	
}