/*importx("com.attilax/web/dslUtil.js");
importx("com.attilax/core/jqUtil.js");
importx("com.attilax/core/ex.js");
importx("com.attilax/core/core.js");
importx("com.attilax/text/str.js");
importx("com.attilax/web/urlUtil.js");
importx("com.attilax/templete/jquery.tmpl.js");
importx("com.attilax/jsbridge/jsb_v7q329.js");
//importx("00.atilax.frmwk/validation.js");
importx("com.attilax/util/valid.js");
importx("com.attilax/ui/TableV2.js");
importx("com.attilax/dataService/dataServiceV3q41.js");
*/


function sala_mode_click()
{
 var v=$("#sala_mode").val();
  //    alert(v);

           if(v==""  || v=="$null")
			where=""
		else
			where=" where sala_mode='"+v+"'";
	query_bindTable(where);

}



function cate_click()
{
 var v=$("#cate_id").val();
   //  alert(v);

        if(v=="" || v=="$null")
			where=""
		else
			where=" where cate_id='"+v+"'";
	query_bindTable(where);

}


function query_bindTable(where)
{

   try{
	var ds=new dataServiceV3();
	var s="select * from wxb_good_copy  t left join wxb_good_type c on t.cate_id=c.type_id "+where+" order by art_id desc limit 30";
		s=encodeURIComponent(s);
		ds.query("$tb="+s+"&$tbtype=sq&$trigger000=com.attilax.dataService.meta_data_pars_from_txt_trigger&$trigtime=after&order_id=$uuid"+"&user_id=$uid&$member_id=$uid",function(data){
			console.log("--r:"+data);

			try{
			var tb=new TableV2("table1");
			tb.bindData( str2json(data));
		}catch(e){ showErr(e); }
		//	alert("操作成功");
		//   data=str2json(data);
		//　$("#table1_tmpl").tmpl(data).appendTo('#table1');	
	    //  $("#table1 tr").eq(1).hide(); //tr0 is head ,,tr1 is tmpl
			
		}
		
		
		); 


	}catch(e)
	{
		showErr(e);
	}


}
function area_click()
{

  var v=$("#area_slt").val();
  //    alert(v);

      if(v==""  || v=="$null")
			where=""
		else
			where=" where location='"+v+"'";


  
	//	ds.formid="formx";
	//	alert();
	//	var s="update  `wxb_order` set stat='取消' where user_id=$uid$ and oid="+order_id;
		

		query_bindTable(where);
	



}


function bindEvt()
{

$('#area_slt').on('change', area_click);
$('#cate_id').on('change', cate_click);
$('#sala_mode').on('change', sala_mode_click);

//function() {});

}


window.onload=function()
{


	bindEvt();
}