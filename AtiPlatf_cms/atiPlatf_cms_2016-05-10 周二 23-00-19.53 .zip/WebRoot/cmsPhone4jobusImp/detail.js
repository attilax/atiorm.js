// JavaScript Document
  $glob={};
  $glob.InsertOrderCount=0;
get_post_sql="select * from arts where copy_id='@id@'"



var merge_callback= function(data)
{
	 jo=str2json(data);
	   logx(data);
	   
	   try{
	 	  processJavaEx_V2q315(data);
	   }catch(e)
	   {
		//   alert(data);
		 //  showErr(data);
			if(catchEx(e,"com.attilax.user.NotLoginEx"))
			  {
				  alert("not login");
					logx("not login");
					return;
					//window.location="../user/login.html";
			  }
			  alert("--e:  " +data);
			  return;
//			  else{
			//	  logx("logined"); alert("login");
				//  }
	   }	
	 alert("报名成功!!");
	//   if(!this.disableDefRetOkMsg)
	//   alert("保存成功，返回结果:"+data);
	    if(data==1)
		{
			 $glob.InsertOrderCount++;
			//if(confirm("转到查看页面??"))
		//	{
			//	window.location=this.merge_after_goto_url;	
			//}
		}
	
	
}
function btn_click()
{
	var ds=new dataServiceV3();
	ds.retOkMsg="报名成功!!";
	ds.merge_after_goto_url=window.location;
	ds.disableDefRetOkMsg=true;
	
	var arr=$("#table1 .art_id");
	var obj=arr.get(0);
	var art_id=$(obj).text();
	//ds.merge_after_goto_url="../cust/goods/copy/list?envi=cp";
	ds.merge("$tb=wxb_order&$trigger000=com.attilax.dataService.meta_data_pars_from_txt_trigger&$trigtime=after&order_id=$uuid&good_id="+art_id+"&user_id=$uid",merge_callback);
}


function cateColor(cate)
{
//	var a=catesQ319.split(",");
	
 //	alert("--cate:"+cate);
//	var v=catesQ319_json[cate];
if(cate==="")
{
//	alert("is emty");
	return "BA8FBA";
}
   return 	cate;
}


function get_post_callback(data)
{
	 //alert(data);
	var li=str2json(data);
	//fix alisa_code
	 for(i=0;i<li.length;i++)
	{
		var o=li[i];
		if(o["alisa_code"]==null)
			o["alisa_code"]="";	
	}
 
	try{
		var o=li[0];
		$("#needcount").html(o.needcount);
		$(".needcount").html(o.needcount);
		　$("#table1_tmpl").tmpl(li).appendTo('#table1');
		　$("#table1_tmpl").hide();
		  $("#mer_tel_a").attr("href","tel:"+li[0].tel);
		   countNeedNums(o.art_id);
		   getInsertOrderCount(o.art_id);
	}catch(e)
	{
 		showErr(e);	
	}
//	$("#material_description").text(data.material_description);
	
	
}
var page_loadQ330_flag=false;
  function page_loadQ330()
  {
	 if(page_loadQ330_flag)
		 return;
	   page_loadQ330_flag=true;
	     var id=UrlParm.parm('id');
		// alert(id);
		 get_post(id);
		
		 
		 
  }
  
  function insert_order()
  {
	  alert("响应成功，请等待 回应");
  }

  
  
  function  infoFullCheck_back(data)
  {
      var o=str2json(data);
	  o=o[0];
	  if(o.realname && o.realname!="" )
		  $glob.infoFulled=true;
	else
	$glob.infoFulled=false;
  
  }
  function infoFullCheck()
  {
	  window.setTimeout(function(){
			var ds=new dataServiceV3();  
		  var s="select * from wxb_memeber t where t.memeber_id=$uid$";
		  s=encodeURIComponent(s);
		  
		  ds.query("$tb="+s+"&$tbtype=sq&$trigg er000=com.a	ttilax.dataService.meta_data_pars_from_txt_trigger&$trigtime=after&order_i d=$uuid"+"&	user_id=$uid&$member_id=$uid",infoFullCheck_back);
	
 
		  
		  },1000);  
  }
  
  
  function getInsertOrderCount(art_id)
  {
	  	var ds=new dataServiceV3();  
		  var s="select count(*) as nums from wxb_order   where good_id='$obj_id$' and user_id=$uid$";
		  s=s.replace("$obj_id$",art_id);
		   console.log(s);
		  s=encodeURIComponent(s);
		  
		  ds.query("$tb="+s+"&$tbtype=sq&$trigg er000=com.a	ttilax.dataService.meta_data_pars_from_txt_trigger&$trigtime=after&order_i d=$uuid"+"&	user_id=$uid&$member_id=$uid",function(data)
		  {
			    console.log(data);
			    var o=str2json(data);
				  o=o[0];
				  $glob.InsertOrderCount=o.nums;
			  
		  });
	  
  }
  
  
  /**
    <a href="javascript:btn_click();" class=""  style="color:#666"  onclick="return infoFullCheck_btn_click()">
  
  */
  function infoFullCheck_btn_click()
  {
	  if($glob.infoFulled==undefined)
	  {
		  $glob.infoFulled=true;
	 // 	alert("状态不明,请重新刷新");
	//	return false;
//	return true;
	  }
	   if($glob.infoFulled==false)
	   {
		alert("请先完善信息");
		return false;   
	   }
	   if( $glob.InsertOrderCount>0)
	   {
		   alert("已经提交过了");
		   return false;  
	   }
	return  $glob.infoFulled;
	  
  }
  
  function  countNeedNums(art_id)
  {
	   //$("#needcount_already").html(123);
	  //	get_post_sql="select * from arts where copy_id='@id@'" 
	  	var ds=new dataServiceV3();  
		  var s="select count(*) num from wxb_order where good_id='"+ art_id+"'";
		  s=encodeURIComponent(s);
		  
		  ds.query("$tb="+s+"&$tbtype=sq&$trigg er000=com.a	ttilax.dataService.meta_data_pars_from_txt_trigger&$trigtime=after&order_i d=$uuid"+"&	user_id=$uid&$member_id=$uid",function(data){
			  var a=str2json(data);
			  var vx=a[0].num;
			  $(".needcount_already").html(vx); 
			//  $("#needcount_already").text("12300");
		  });
 
  }
  
