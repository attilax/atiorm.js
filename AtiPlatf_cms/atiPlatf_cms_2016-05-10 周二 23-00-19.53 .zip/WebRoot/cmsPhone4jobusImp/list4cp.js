//page gui


//q321
var catesQ319="派单:F19ABD,促销:F1E541,家教:B6DDC8,实习:7BC5A0,其他:BA8FBA";
var catesQ319_json=yaml2json(catesQ319);


var get_posts_sql="select * from wxb_good_copy  t left join wxb_good_type c on t.cate_id=c.type_id order by art_id desc limit 30";


function cateColor(cate)
{
//	var a=catesQ319.split(",");
	
 //	alert("--cate:"+cate);
//	var v=catesQ319_json[cate];
if(cate==="")
{
//	alert("is emty");
	return "BA8FBA";
}
   return 	cate;
}
function get_posts_callback(data)
{
	 //alert(data);
	data=str2json(data);
	for(i=0;i<data.length;i++)
	{
	var o=data[i];
	if(o["alisa_code"]==null)
		o["alisa_code"]="";	
	}
 
	try{
			bindPa(data);
	}catch(e)
	{
 		showErr(e);	
	}
 
	
	
}
function bindPa(li){
	
	try{
		　$("#table1_tmpl").tmpl(li).appendTo('#table1');
	//	alert("ok");
	}catch(e){ 
	console.log("---bindPa  err happend");
	 showErr(e);
	}
	};

function menu_click2(cate)
{
	 $("#doc-oc-demo2").offCanvas('close');
	  $("#wrapper").css("margin-top","0px");
 get_posts({"cate":cate});	

}

function clr_list_area()
{
$("#table1").html("");	
 

}


var   load_img=function()
{

 
	return;
	console.log("--start load img");
	
	for(var i=2;i<=4;i++)
	{
		$("#img__"+i).attr("src","images/"+i+".jpg");
		
	}
	console.log("--finish load img");
	
	
 
	 
	  console.log("--finish unslider..");
 		//end
 

};


function page_load()
{
/*var o={	pagesize:3,keyword:"",rows:arr,bind_handler:bindPa};
	//page gui
	//alert(listPaf2);
	 listPaf2(o);*/
	 try{
		 
	//	 setPageSpy();
	 next_click();
	// next_click();
		 
	$("#table1_tmpl").hide();	
	
//	iniMenuEvent();
	
	$(function()
{
	
	window.setTimeout(load_img,500);

});

bindEvt();


	
	 }catch(e)
	 {
		showErr(e); 
	 }
}

function iniMenuEvent()
{
$("#left_menu_div span").each(function(index, element) {
    $(element).click(function(){
		var cate=$(this).text();
		menu_click2(cate);
		
	});
	
});
	
}


function substrPa(str)
	{
		return str.substr(0,12);
		
	}
$.fn.isOnScreen = function(){
     
    var win = $(window);
     
    var viewport = {
        top : win.scrollTop(),
        left : win.scrollLeft()
    };
    viewport.right = viewport.left + win.width();
    viewport.bottom = viewport.top + win.height();
     
    var bounds = this.offset();
    bounds.right = bounds.left + this.outerWidth();
    bounds.bottom = bounds.top + this.outerHeight();
     
    return (!(viewport.right < bounds.left || viewport.left > bounds.right || viewport.bottom < bounds.top || viewport.top > bounds.bottom));
     
};


/*
$(function() {
	
//	menu_click2("爱情类");
window.setInterval(function(){
//	var rzt=$("#scrool_spy").isOnScreen();
	if(rzt)
		next_click();
	console.log( "visible spy::"+rzt);
	},100);

	});*/