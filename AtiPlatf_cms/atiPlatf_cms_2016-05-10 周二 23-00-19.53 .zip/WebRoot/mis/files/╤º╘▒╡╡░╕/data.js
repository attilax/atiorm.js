﻿$axure.loadCurrentPage(
(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,c,d,e,f,g,h,g,i,[j,k,l],m,_(n,o,p,q,r,s,t,_(),u,_(v,w,x,y,z,_(A,B,C,D),E,null,F,y,G,y,H,I,J,null,K,L,M,N,O,P,Q,L),R,_(),S,_(),T,_(U,[])),V,_(),W,_());}; 
var b="url",c="学员档案.html",d="generationDate",e=new Date(1461155757467.69),f="isCanvasEnabled",g=false,h="isAdaptiveEnabled",i="variables",j="OnLoadVariable",k="rl_date",l="rl_day",m="page",n="packageId",o="75d45be4ce214ca3bc703f9590ed439c",p="type",q="Axure:Page",r="name",s="学员档案",t="notes",u="style",v="baseStyle",w="627587b6038d43cca051c114ac41ad32",x="pageAlignment",y="near",z="fill",A="fillType",B="solid",C="color",D=0xFFFFFFFF,E="image",F="imageHorizontalAlignment",G="imageVerticalAlignment",H="imageRepeat",I="auto",J="favicon",K="sketchFactor",L="0",M="colorStyle",N="appliedColor",O="fontName",P="Applied Font",Q="borderWidth",R="adaptiveStyles",S="interactionMap",T="diagram",U="objects",V="masters",W="objectPaths";
return _creator();
})());