var tr=$(".main_div tr:first")
var count=0;
 $(tr).children("td").each(function(i){
      //  alert("��"+i+"��td�����ݣ�"+$(this).text());
      //  count
      count++;
    });
 //alert(count);
 if(count>9)
 	$(".main_div").css("width","100%");