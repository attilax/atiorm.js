 
 
 
 

 
 
//importx("com.attilax/core/coreV2.js");

function page_load()
{
	
	var saveDir="00upQ4";
	 saveDir=encodeURIComponent(saveDir);
var uploadSrv=new  AtiUploadV3("#idcardFace");
uploadSrv.up_url=$approot+"/upServlet?savepath="+saveDir;

$('#idcardFace').change(function(){
	 uploadSrv.upload();
	 
	  });
 
 
 

 
uploadSrv.upload_finish_handler=function(data){
	data=data.trim();
	console.log("upload_finish_handler:"+ data);
	console.log("上传结束返回结果:"+data);
	$("#img1").val(data);
	var url=getPicSrc4createObjectURL("idcardFace");
	console.log(url);
	$("#img1_img").attr("src",url);
};
//----------------------------------------

var uploadSrv2=new  AtiUploadV3("#idcardBack");
uploadSrv2.up_url=uploadSrv.up_url;
 $('#idcardBack').change(function(){
	 uploadSrv2.upload();
	 
	  });


uploadSrv2.upload_finish_handler=function(data){
	data=data.trim();
	console.log("upload_finish_handler:"+ data);
	console.log("上传结束返回结果:"+data);
	$("#img2").val(data);
	var url=getPicSrc4createObjectURL("idcardBack");
	console.log(url);
	$("#img2_img").attr("src",url);
};
	
}



function btn_click()
{
	if($("#realname").val()==""){
	alert("请输入数据");
	return;}
		var ds=new dataServiceV4();
		ds.formid="formx";
	//	alert();
		//var s="select * from wxb_memeber where memeber_id=$uid$";
	//	s=encodeURIComponent(s);
	var	s="sid";
		ds.insert("$tb="+s+"&$tbtype00=sq&$trigger000=com.attilax.dataService.meta_data_pars_from_txt_trigger&$trigtime=after&order_id=$uuid"+"&user_id=$uid&uid=$uid",function(data)
		{
			 console.log("--btn_click rzt:"+data);
			 alert("ok");
			
		}); 
	
	
}