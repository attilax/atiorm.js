  window.onerror=function(errorMessage, scriptURI, lineNumber, columnNumber, error)
  { 
 
	  //ip6  cp hto only 4g param   ma zuihou yig...first param is object
	//  alert( JSON.stringify(arguments));
	//  alert(error);
	 //	 alert( JSON.stringify(errorMessage));
	try{
	 var errmsg=JSON.stringify(arguments);
	 console.log(errmsg);
	 errmsg=encodeURIComponent(errmsg);
	  var  mp="$method=com.attilax.log.FileLogService.log&$callback=page_load_callback&$mod=userMod&$tabletype=view&$table=orderView&$view_store_path=com/attilax/order&$op=insert&param="+errmsg;
		 //	alert("get post mp:"+mp);
	 
	HRE.exe(mp,function(data)
		{
			console.log(data);
		}
	);	
	}catch(e)
	
	{  // trycatch  beir recyele err.
	    console.log(e);	
	}
	 
 
  }
  var loginStat=false;
   function page_load_callback(data)
  {
	  jo=str2json(data);

	   logx(data);
	   
	   try{
	 	  processJavaEx_V2q315(data);
	   }catch(e)
	   {
				if(catchEx(e,"com.attilax.user.NotLoginEx"))
			  {
				//  alert("not login£¬ÕýÔÚ×ªÍùµÇÂ½½çÃæ");
					logx("not login");
				//	window.location="../user/login.html";
				  loginStat=false;
				 $("#reg_block").show();
				 return;
			  }
			  throw e;
			   
	   }


				  logx("logined"); 
				  loginStat=true;
				  //alert("login");
				  $("#reg_block").hide();
				 
	   
	   	  jo=jo[0];
	  for (prop in jo)
	  {
		  if(jo[prop]!=null)
		  $("#"+prop).text( jo[prop]);
	  }
	  
	  var aform=new AForm();
	  aform.base="../";
	  aform.bind(jo);
	
	 // if(jo["@type"]=="")
		
//alert(data);

  }  
  window.onerror_depxxx=function(errorMessage, scriptURI, lineNumber, columnNumber, error)
  { 
  try{
	  //ip6  cp hto only 4g param   ma zuihou yig...first param is object
	//  alert( JSON.stringify(arguments));
	//  alert(error);
	 	 alert( JSON.stringify(errorMessage));
	 if(error==undefined)
			 error=errorMessage;
		  if(catchEx(error,"com.attilax.user.NotLoginEx"))
		  {
			  alert("not login");
				logx("not login");
				window.location="../user/login.html";
		  }
		  else{
			  logx("logined"); alert("login");
			  }
  }catch(e)
  {
	showErr(e);  
  }
  }
  
  
  
 
  function page_load()
  {
	//  alert(aaaa);
	  
	     	var mp="";//$("#formx").serialize();
			var sql="select * from wxb_memeber t where t.memeber_id=$uid$";
				sql=encodeURIComponent(sql);
	  mp=mp+"&$method=com.attilax.sql.SqlService.executeQuery&$callback=page_load_callback&$mod=userMod&$tabletype=view&$table=orderView&$view_store_path=com/attilax/order&$op=insert&param="+sql;
		 //	alert("get post mp:"+mp);
		 try{
	HRE.exe(mp,page_load_callback);	
		 }catch(e)
		 {
			 alert(e);
		 }


		      $("#main_divQ5").bind("click", function () {
		      	console.log(" document client evt..");
                  if(!loginStat)
                  {
	 					if(confirm("您还没有登录，请先登录"))
	                  	{
	                  			window.location="../user/login.html";
	                  	}
                  	 	return false;
                  }

                  if(loginStat)
                  {
                  	
                  }


                 
                 

		      });
		 
		// alert(fortest_global_err);
		 
  }
  page_load();
 