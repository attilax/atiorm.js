  function page_load_callback(data)
  {
	  jo=str2json(data);
	   logx(data);
	   
	   try{
	 	  processJavaEx_V2q315(data);
	   }catch(e)
	   {
				if(catchEx(e,"com.attilax.user.NotLoginEx"))
			  {
				 // alert("not login");
					logx("not login");
					if(confirm("您还没有登陆或者过期超时，请重新登陆"))
					window.location="../userPhone4jobusImp/mer_login.html";
			  }
			  else{
				  logx("logined"); alert("login");
				  }
	   }
	   
	  for (prop in jo)
	  {
		  $("#"+prop).text( jo[prop]);
	  }
	
	 // if(jo["@type"]=="")
		
//alert(data);

  }  
  window.onerror_depxxx=function(errorMessage, scriptURI, lineNumber, columnNumber, error)
  { 
  try{
	  //ip6  cp hto only 4g param   ma zuihou yig...first param is object
	//  alert( JSON.stringify(arguments));
	//  alert(error);
	 	 alert( JSON.stringify(errorMessage));
	 if(error==undefined)
			 error=errorMessage;
		  if(catchEx(error,"com.attilax.user.NotLoginEx"))
		  {
			  alert("not login");
				logx("not login");
				window.location="../user/login.html";
		  }
		  else{
			  logx("logined"); alert("login");
			  }
  }catch(e)
  {
	showErr(e);  
  }
  }
  function page_load()
  {
	     	var mp="";//$("#formx").serialize();
	  mp=mp+"&$method=com.attilax.user.UserService.getCurUserinfo&$callback=page_load_callback&$mod=userMod&$tabletype=view&$table=orderView&$view_store_path=com/attilax/order&utype=mer";
		 //	alert("get post mp:"+mp);
		 try{
	HRE.exe(mp,page_load_callback);	
		 }catch(e)
		 {
			 alert(e);
		 }
		 
  }
  page_load();