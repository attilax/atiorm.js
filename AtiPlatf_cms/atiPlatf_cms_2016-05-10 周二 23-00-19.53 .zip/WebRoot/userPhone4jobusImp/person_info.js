
 


importx("com.attilax/dataService/dataServiceV2q329.js");
importx("com.attilax/web/dslUtil.js");
importx("com.attilax/core/jqUtil.js");
importx("com.attilax/core/ex.js");
importx("com.attilax/core/core.js");
importx("com.attilax/text/str.js");
importx("com.attilax/web/urlUtil.js");

//com.attilax/text/str.js
importx("com.attilax/jsbridge/jsb_v7q329.js");
importx("com.attilax/dataService/dataServiceV3q41.js");

function page_load()
{
	try{
	var ds=new dataServiceV3();
		ds.formid="formx";
	//	alert();
		var s="select * from wxb_memeber where memeber_id=$uid$";
		s=encodeURIComponent(s);
		ds.query("$tb="+s+"&$tbtype=sq&$trigger000=com.attilax.dataService.meta_data_pars_from_txt_trigger&$trigtime=after&order_id=$uuid"+"&user_id=$uid&$member_id=$uid",function(data)
		{
			var  jo=str2json(data);
			  jo=jo[0];
			  var aform=new AForm();
				  aform.base="../";
				  aform.bind(jo);	
			
		}); 
	}catch(e)
	{
		showErr(e);
	}
	
}



 function btn_click()
 {
	 
	 try{
		var ds=new dataServiceV3();
		ds.formid="formx";
	//	alert();
		ds.merge("$tb=wxb_memeber"+"&$tbtype=&$trigger000=com.attilax.dataService.meta_data_pars_from_txt_trigger&$trigtime=after&order_id=$uuid"+"&user_id=$uid&$member_id=$uid"); 
		
		}catch(e)
	{
		showErr(e);
	}
 }
