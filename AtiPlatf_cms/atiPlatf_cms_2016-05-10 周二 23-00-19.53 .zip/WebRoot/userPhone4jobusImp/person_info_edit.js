
 


importx("com.attilax/dataService/dataServiceV2q329.js");
importx("com.attilax/web/dslUtil.js");
importx("com.attilax/core/jqUtil.js");
importx("com.attilax/core/ex.js");
importx("com.attilax/core/core.js");
importx("com.attilax/text/str.js");
importx("com.attilax/web/urlUtil.js");

//com.attilax/text/str.js
importx("com.attilax/jsbridge/jsb_v7q329.js");
importx("com.attilax/dataService/dataServiceV3q41.js");
importx("com.attilax/io/uploadV3.js");
importx("com.attilax/ui/AForm.js");
var uploadSrv;
function page_load()
{
	var ds=new dataServiceV3();
		ds.formid="formx";
	//	alert();
		var s="select * from wxb_memeber where memeber_id=$uid$";
		s=encodeURIComponent(s);
		ds.query("$tb="+s+"&$tbtype=sq&$trigger000=com.attilax.dataService.meta_data_pars_from_txt_trigger&$trigtime=after&order_id=$uuid"+"&user_id=$uid&$member_id=$uid",function(data)
		{
			var  jo=str2json(data);
			  jo=jo[0];
			  var aform=new AForm();
				  aform.base="../";
				  aform.bind(jo);	
				  if(jo.thumb)
					  $("#headImage").attr("src","../"+jo.thumb);
			
		}); 
	

var saveDir="00upQ4";
saveDir=encodeURIComponent(saveDir);
uploadSrv=new  AtiUploadV3("#userHeadImage");
uploadSrv.up_url=$approot+"/upServlet?savepath="+saveDir;
 
uploadSrv.upload_finish_handler=function(data){
	data=data.trim();
	console.log("upload_finish_handler:"+ data);
	console.log("上传结束返回结果:"+data);
	$("#thumb").val(data);
	var url=getPicSrc4createObjectURL("userHeadImage");
	console.log(url);
	$("#headImage").attr("src",url);
};


}

/*window.alert=function(msg)
{
console.log(msg);	
}*/

 function btn_click()
 {
	 
		var ds=new dataServiceV3();
		ds.formid="formx";
	//	alert();
	//var thumb=$("#userHeadImage")
		ds.merge("$tb=wxb_memeber"+"&$tbtype=&$trigger000=com.attilax.dataService.meta_data_pars_from_txt_trigger&$trigtime=after&order_id=$uuid"+"&user_id=$uid&thumb=$uid"); 
 }
